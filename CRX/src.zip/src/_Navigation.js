import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
const { Navigator, Screen } = createStackNavigator();
import { SplashScreen } from './SplashScreen';
import { MainScreen } from './MainScreen';
import { SymptomTracker } from './subScreens/SymptomTracker';
import { Xray } from './subScreens/Xray';
import { useEffect } from 'react/cjs/react.production.min';

const HomeNavigator = () => (
  <Navigator headerMode='none'>
  
    <Screen name='splash' component={SplashScreen}/>
    <Screen name='main' component={MainScreen}/>
    <Screen name='symptom' component={SymptomTracker}/>
    <Screen name='xray' component={Xray}/>

  </Navigator>
);

// useEffect(()=>{console.log('navigation');});

export const AppNavigator = () => (
  <NavigationContainer>
    <HomeNavigator/>
  </NavigationContainer>
);

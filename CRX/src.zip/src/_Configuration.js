import React from 'react';
//const axios = require('axios').default;

export const app_name = 'MyBin';
export const default_theme = 'light';
// export const cipher = 'mybin-41557896412da45';
// export const API_URL = 'https://mybin.nextgenapps.dev/';

// export const API = axios.create({
//   baseURL: API_URL,
//   timeout: 10000,
//   headers: {'x-application': 'mybin'},
// });

export const API_VERSION = 'v3';

export const ThemeContext = React.createContext({
  theme: 'light',
  toggleTheme: () => {},
});

import React, { useRef,useState, useEffect } from 'react';


import * as ImagePicker from 'react-native-image-picker';
import * as eva from '@eva-design/eva';
import { ApplicationProvider, IconRegistry, useTheme } from '@ui-kitten/components';
import { EvaIconsPack } from '@ui-kitten/eva-icons';


import { StyleSheet,Keyboard, SafeAreaView, TouchableWithoutFeedback, Image, useWindowDimensions, View, DrawerLayoutAndroid, ImageBackground, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { IndexPath, Drawer, DrawerItem, BottomNavigation, BottomNavigationTab, Button, Datepicker, Autocomplete, AutocompleteItem, RadioGroup, Radio, Card, CheckBox, Divider, Layout, TopNavigation, Icon, Input, Text, TopNavigationAction } from '@ui-kitten/components';
import { BallIndicator, BarIndicator, DotIndicator, MaterialIndicator, PacmanIndicator, PulseIndicator, SkypeIndicator, UIActivityIndicator, WaveIndicator,} from 'react-native-indicators';
// import {storeData, getData} from './_AsyncStorage';
import SelectMultiple from '@horizonlime/react-native-select-multiple'


export const  Xray = () => {
    const windowWidth = useWindowDimensions().width;
    const windowHeight = useWindowDimensions().height;
    const [image, setImage] =  React.useState('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADMAAAAzCAYAAAA6oTAqAAAAEXRFWHRTb2Z0d2FyZQBwbmdjcnVzaEB1SfMAAABQSURBVGje7dSxCQBACARB+2/ab8BEeQNhFi6WSYzYLYudDQYGBgYGBgYGBgYGBgYGBgZmcvDqYGBgmhivGQYGBgYGBgYGBgYGBgYGBgbmQw+P/eMrC5UTVAAAAABJRU5ErkJggg==');
    const [newImage, setNewImage] =  React.useState('');
   
  return (
      <Layout style={{backgroundColor:'#f2e5fe',height:windowHeight,width:windowWidth}}>
         <Text>Xray Tracker</Text>

         <Card>
                    <Text>Upload a X-Ray photo </Text>
                    
                    <TouchableOpacity onPress={()=>{

                    }}>
                       <View style={{height: windowWidth, width: windowWidth-30,  borderWidth: 1, borderColor: '#111', justifyContent: 'center', alignItems: 'center', marginTop: 30, alignSelf: 'center'}}>
                       {/* <Image source={{uri: 'https://reactjs.org/logo-og.png'}}
       style={{width: 400, height: 400}} /> */}

                       <Image
                            style={{width:200,height:100}}
                            source={{ uri :image }}
                        />
                       
                        </View>
                  </TouchableOpacity>
                  <View style={{flex:1, flexDirection: 'row', justifyContent: 'space-around', marginTop: 25,marginBottom:50}}>
                  <Button size='small' status='primary' onPress={()=>{
                    ImagePicker.launchCamera(
                      {
                        mediaType: 'photo',
                        includeBase64: true,
                        maxHeight: 1024,
                        maxWidth: 1024,
                      },
                      (response) => {
                        if(response.uri){
                          setImage('data:' + response.type + ';base64,' + response.base64);
                          console.log('data:' + response.type + ';base64,' + response.base64);
                        }
                      },
                    );
                  }}>
                  Take Photo
                  </Button>
                  <Button size='small' status='primary' onPress={()=>{
                    ImagePicker.launchImageLibrary(
                      {
                        mediaType: 'photo',
                        includeBase64: true,
                        maxHeight: 1024,
                        maxWidth: 1024,
                      },
                      (response) => {
                        if(response.uri){
                          setImage('data:' + response.type + ';base64,' + response.base64);
                          console.log('data:' + response.type + ';base64,' + response.base64);
                        }
                      },
                    );
                  }}>
                  Choose from photos
                  </Button>
                        <Button size='small' status='primary' 
                        // onPress={onOperationPress}
                        >Upload</Button>
                         
                        </View>
                      
                    </Card>
         

      </Layout>
   
  );
}

const styles = StyleSheet.create({
    text: {
      color: "white",
      fontWeight:'bold'
      
    },
    icon:{
        height:20, width:20
    }
  });
import React, { useRef,useState, useEffect } from 'react';



import * as eva from '@eva-design/eva';
import { ApplicationProvider, IconRegistry, useTheme } from '@ui-kitten/components';
import { EvaIconsPack } from '@ui-kitten/eva-icons';


import { StyleSheet,Keyboard, SafeAreaView, TouchableWithoutFeedback, Image, useWindowDimensions, View, DrawerLayoutAndroid, ImageBackground, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { IndexPath, Drawer, DrawerItem, BottomNavigation, BottomNavigationTab, Button, Datepicker, Autocomplete, AutocompleteItem, RadioGroup, Radio, Card, CheckBox, Divider, Layout, TopNavigation, Icon, Input, Text, TopNavigationAction } from '@ui-kitten/components';
import { BallIndicator, BarIndicator, DotIndicator, MaterialIndicator, PacmanIndicator, PulseIndicator, SkypeIndicator, UIActivityIndicator, WaveIndicator,} from 'react-native-indicators';
// import {storeData, getData} from './_AsyncStorage';
import SelectMultiple from '@horizonlime/react-native-select-multiple'


export const  SymptomTracker = () => {
    const windowWidth = useWindowDimensions().width;
    const windowHeight = useWindowDimensions().height;
    const [message, setMessage] = React.useState(['Buddhist',
    'Sikhism',
    'Hinduism',
    'Judaism',
    'Christian',
    'Muslims',]);
    const [passion,setPassion] = React.useState([    ]);
    const [selectedFruits,setSelectedFruits] = React.useState([    ]);


    const fruits = ['Apples', 'Oranges', 'Pears']

    const removeitem =(name)=>{
        var value = name
       console.log(passion + "   "+value)
       var arr = Array.from (passion)
       console.log(arr + name)
       arr = arr.filter(function(item) {
       return item !== value
       })
       let x = arr
       setPassion ([...x])
       console.log(passion +   "  ---> after")
       }
       const selectionHandler=(te)=>{ 

if (passion.includes(te)){
    alert("All Ready added")
}else {
    setPassion((sp) => {
            return [
                te,...sp
            ]
        });
}


        // if (passion.length<50){
        // setPassion((sp) => {
        //     return [
        //         te,...sp
        //     ]
        // });
        // }
        // else{
        // alert("can,t add passion more than 5")
        // console.log(passion.length);
        // }
    }
    const renderLabel = (label, style) => {
        return (
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Image style={{width: 42, height: 42}} source={{uri: 'https://dummyimage.com/100x100/52c25a/fff&text=S'}} />
            <View style={{marginLeft: 10}}>
              <Text style={style}>{label}</Text>
            </View>
          </View>
        )
      }
   const onSelectionsChange = (selectedFruits) => {
        // selectedFruits is array of { label, value }
        setSelectedFruits({ selectedFruits })
      }
    
  return (
      <Layout style={{backgroundColor:'#f2e5fe',height:windowHeight,width:windowWidth}}>
         <Text>S Tracker</Text>


         <Card style={{}}>
                    <ScrollView>
                        <View >
                            <View style={{flex: 1, flexDirection: 'row', marginTop: 5, flexWrap: 'wrap', alignItems: 'flex-start'}}>
                                    {passion.map((item, index) => {
                                        return (
                                        <View style={{borderRadius: 4, margin: 2, backgroundColor: '#3366FF'}}>
                                            <TouchableOpacity index={index} onPress={removeitem.bind(this, item)} style={{margin:2,flexDirection:"row",marginHorizontal:20,justifyContent:'space-between'}}>
                                                <Text category='c1' style={{marginVertical: 2, marginHorizontal:2 , color: 'white'}}>{item}</Text>
                                                </TouchableOpacity>
                                        </View> )
                                    })}
                            </View>
                        </View>
                    </ScrollView>
                </Card>
                <Card >
                    <ScrollView>
                        <View style={{flex: 1, flexDirection: 'row', marginTop: 5, flexWrap: 'wrap', alignItems: 'flex-start'}}>
                                {
                                    message.map((item, index)=> {
                                        return(<View style={{borderRadius: 4, margin: 2, backgroundColor: 'pink'}}>
                                            <TouchableOpacity index={index} onPress={selectionHandler.bind(this, item)}
                                            style={{margin:2,flexDirection:"row",marginHorizontal:5,justifyContent:'space-between'}}>
                                                    <Text style={{marginVertical: 2, marginHorizontal: 2, color: 'black'}}>{item}</Text>
                                            </TouchableOpacity>
                                        </View>
                                        )
                                    })
                                }   
                        </View>
                    </ScrollView>
                </Card>
                {/* <SelectMultiple
          items={fruits}
          renderLabel={renderLabel}
          selectedItems={this.state.selectedFruits}
          onSelectionsChange={onSelectionsChange}
          checkboxIcon={<Ionicons name="ios-radio-button-off" size={30} color={grey} />} /> */}

      </Layout>
   
  );
}

const styles = StyleSheet.create({
    text: {
      color: "white",
      fontWeight:'bold'
      
    },
    icon:{
        height:20, width:20
    }
  });